# Natapp
&nbsp;&nbsp;这是一个内网穿透工具。[https://natapp.cn/](https://natapp.cn/)

&nbsp;&nbsp;启动命令:
+ ./natapp -authtoken=${authtoken}
    - authtoken 为隧道的authtoken